#!/bin/sh
#  Copyright (C) 2022  SEIKO EPSON CORPORATION

dpkg -P epson-backend epson-printer-utility
