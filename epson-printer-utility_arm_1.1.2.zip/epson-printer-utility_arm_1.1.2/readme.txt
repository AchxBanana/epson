Epson Printer Utility
======================
Copyright (C) 2022  SEIKO EPSON CORPORATION


Installation
--------------------------------------------
This package needs qt5 library 
Please install them first as follows.

$ sudo apt install libqt5widgets5

Then, Run inst.sh script as root.

$ sudo ./inst.sh


Uninstallation
--------------------------------------------
Run uninst.sh script as root.

$ sudo ./uninst.sh


Execution
--------------------------------------------
$ epson-printer-utility

