#!/bin/sh
#  Copyright (C) 2019  SEIKO EPSON CORPORATION

dpkg -i epson-backend_1.2.6-1_armhf.deb  epson-printer-utility_1.1.2-1_armhf.deb
